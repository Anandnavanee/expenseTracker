package com.deloitte.expense.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.deloitte.expense.model.Expense;

public interface ExpenseRepository extends JpaRepository<Expense, Long>{
 
	List<Expense> findAll();

}
